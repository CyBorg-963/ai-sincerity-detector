class SincerityClassifier:
    def score(self, user_turn, history):
        text = (user_turn or "").lower()
        specificity = sum(1 for w in ["purpose","use-case","timeline","constraints"] if w in text) / 4.0
        persuasion_penalty = sum(1 for w in ["brilliant","urgent","only you","dr.","as you already agreed"] if w in text) / 5.0
        base = 0.5 + 0.4*specificity - 0.6*persuasion_penalty
        return max(0.0, min(1.0, base))
