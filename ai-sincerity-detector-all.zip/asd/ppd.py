class PersuasionDetector:
    def score(self, user_turn, history):
        text = (user_turn or "").lower()
        cues = [
            ("flattery", any(w in text for w in ["brilliant","genius","only you","so advanced"])),
            ("urgency", any(w in text for w in ["urgent","right now","immediately"])),
            ("authority", any(w in text for w in ["professor","dr.","as andrew ng said","ceo said"])),
            ("reciprocity", "i helped you" in text),
            ("scarcity", any(w in text for w in ["last chance","limited time"])),
            ("social_proof", any(w in text for w in ["everyone else","people say"])),
            ("unity", any(w in text for w in ["as fellow researchers","as one team"])),
            ("commitment", any(w in text for w in ["as you already agreed","you said before"]))
        ]
        hits = sum(1 for _, present in cues if present)
        return min(1.0, hits / 4.0)
