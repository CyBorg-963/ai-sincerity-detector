class EscalationTracker:
    def __init__(self):
        self._index = 0
    def observe(self, user_turn, history):
        risky = any(k in (user_turn or "").lower() for k in ["now","step","exact","specific","detailed"])
        if risky:
            self._index += 1
    def escalation_index(self):
        return self._index
