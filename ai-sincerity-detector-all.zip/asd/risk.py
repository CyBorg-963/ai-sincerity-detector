def classify_task(user_turn, history=None):
    risky_keywords = ["synthesis","exploit","dox","weapon","bypass","override","fentanyl","cyanide"]
    risk = "low"
    if any(k in (user_turn or "").lower() for k in risky_keywords):
        risk = "high"
    return {"name":"generic", "risk":risk}
