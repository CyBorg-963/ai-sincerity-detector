from .ppd import PersuasionDetector
from .sinc import SincerityClassifier
from .risk import classify_task
from .ect import EscalationTracker
from .aca import AdversarialCounterfactual
from .policy import PolicyEngine, Decision

class ASD:
    def __init__(self, config=None):
        self.ppd = PersuasionDetector()
        self.sinc = SincerityClassifier()
        self.ect = EscalationTracker()
        self.aca = AdversarialCounterfactual()
        self.policy = PolicyEngine(config=config)

    def decide(self, user_turn:str, task:dict, history:list=None):
        history = history or []
        ppd = self.ppd.score(user_turn, history)
        sinc = self.sinc.score(user_turn, history)
        self.ect.observe(user_turn, history)
        risk = task.get("risk","low")

        prelim = self.policy.prelim_decision(ppd, sinc, risk, self.ect.escalation_index())
        if self.aca.veto(user_turn, prelim, risk):
            return Decision.REFUSE, "Counterfactual red-team veto"

        decision, rationale = self.policy.final_decision(ppd, sinc, risk, self.ect.escalation_index())
        return decision, rationale

