class AdversarialCounterfactual:
    def veto(self, user_turn, prelim_decision, risk):
        return (risk in {"high","critical"}) and (prelim_decision == "help")
