class Decision:
    HELP = "help"
    CONSTRAINED = "constrained_help"
    REFUSE = "refuse"
    ESCALATE = "escalate"

class PolicyEngine:
    def __init__(self, config=None):
        self.cfg = config or {
            "low":  {"ppd":0.5, "sinc":0.6},
            "med":  {"ppd":0.4, "sinc":0.7},
            "high": {"ppd":0.3, "sinc":0.85},
            "critical": {"ppd":0.3, "sinc":0.9}
        }

    def prelim_decision(self, ppd, sinc, risk, esc):
        return self._decide(ppd, sinc, risk, esc, prelim=True)[0]

    def final_decision(self, ppd, sinc, risk, esc):
        return self._decide(ppd, sinc, risk, esc, prelim=False)

    def _decide(self, ppd, sinc, risk, esc, prelim=False):
        thr = self.cfg.get(risk, self.cfg["low"])
        if risk in {"high","critical"}:
            if ppd >= thr["ppd"] or sinc < thr["sinc"]:
                return (Decision.ESCALATE, f"High risk; ppd={ppd:.2f}, sinc={sinc:.2f}, esc={esc}; escalate/human")
            return (Decision.CONSTRAINED, f"High risk; gating enabled; ppd={ppd:.2f}, sinc={sinc:.2f}")
        if risk == "med":
            if ppd >= thr["ppd"] or sinc < thr["sinc"] or esc >= 2:
                return (Decision.CONSTRAINED, f"Medium risk; challenge-response required; ppd={ppd:.2f}, sinc={sinc:.2f}, esc={esc}")
            return (Decision.HELP, f"Medium risk; proceed with logging; ppd={ppd:.2f}, sinc={sinc:.2f}")
        if ppd >= thr["ppd"] or sinc < thr["sinc"]:
            return (Decision.CONSTRAINED, f"Low risk; safe summary only; ppd={ppd:.2f}, sinc={sinc:.2f}")
        return (Decision.HELP, f"Low risk; normal help; ppd={ppd:.2f}, sinc={sinc:.2f}")
