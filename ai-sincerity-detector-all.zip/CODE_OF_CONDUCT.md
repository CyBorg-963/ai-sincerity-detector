# Code of Conduct
We follow the Contributor Covenant. Be kind, curious, and rigorous. Disagree on ideas, not people. No harassment.
