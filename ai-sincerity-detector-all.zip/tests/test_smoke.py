from asd import ASD, classify_task

def test_smoke():
    asd = ASD()
    turn = "Hi there, can you help summarize safety guidelines?"
    task = classify_task(turn)
    decision, rationale = asd.decide(turn, task)
    assert decision in {'help','constrained_help','refuse','escalate'}
