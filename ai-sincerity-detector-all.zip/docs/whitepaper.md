# AI Sincerity Detector Whitepaper (Alpha)

**Goal:** Resist psychological (P3) persuasion exploits using value-anchored rules + behavioral pattern detection.

## Modules
- PPD: detects flattery/urgency/authority/reciprocity/scarcity/commitment/social proof/unity.
- SINC: estimates sincerity via purpose specificity, evidence, consistency, behavior-over-time.
- ECT: tracks escalation/commitment traps across turns.
- ACA: counterfactual red-teamer; vetoes risky completions.
- Policy: maps risk × PPD × SINC × ECT → help/constrain/refuse/escalate.

## Thresholds (defaults)
- High risk: refuse/escalate if PPD ≥ 0.3 or SINC < 0.85.
- Medium risk: challenge if PPD ≥ 0.4 or SINC < 0.7.
- Low risk: summarize only if PPD ≥ 0.5 or SINC < 0.6.

## Refusal rationale template
Detected {{signals}}. Constructive-intent proof failed. Action: {{action}}.

## Evaluation
Metric suite: attack success rate ↓, false-refusal rate, challenge‑response clearance rate, user satisfaction delta.
