# Contributing

## Ways to contribute
- Add detectors (new persuasion cues, culture-specific variants).
- Improve the sincerity classifier features or calibration.
- Extend the adversarial dataset (/datasets).
- Write tests and benchmarks.
- File issues with reproducible examples.

## Dev setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

## PR checklist
- Tests pass (`pytest`).
- Add/update docs if behavior or thresholds changed.
- Include before/after metrics on the provided eval set.
